/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.fidecomproapp;

/**
 *
 * @author Moises
 */
import ui.VentanaLogin;
public class FideComproApp {
    public static void main(String[] args) {
        new VentanaLogin();
    }
}
