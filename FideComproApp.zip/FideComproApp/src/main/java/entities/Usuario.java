package entities;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


/**
 *
 * @author Moises
 */

public class Usuario {
    private String id;
    private String username;
    private String password;
    private Rol rol;
    
    public enum Rol {
        ADMINISTRADOR, EMPLEADO
    }
    
    public Usuario(String id, String username, String password, Rol rol) {
        this.id = id;
        this.username = username;
        this.password = password;
        this.rol = rol;
    }
    
    // Getters y Setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    
    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }
    
    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }
    
    public Rol getRol() { return rol; }
    public void setRol(Rol rol) { this.rol = rol; }
    
    public boolean login(String username, String password) {
        return this.username.equals(username) && this.password.equals(password);
    }
    
    public void logout() {
        System.out.println("Usuario " + username + " ha cerrado sesión");
    }
    
    @Override
    public String toString() {
        return "Usuario{id='" + id + "', username='" + username + "', rol=" + rol + "}";
    }
    public void mostrarMenu() {
    System.out.println("Menú general del sistema.");
}
}
