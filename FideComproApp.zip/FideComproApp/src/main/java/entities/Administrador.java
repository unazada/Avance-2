/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entities;

/**
 *
 * @author Moises
 */
public class Administrador extends Usuario {
    
    public Administrador(String id, String username, String password) {
        super(id, username, password, Rol.ADMINISTRADOR);
    }

    public void generarReporteVentas() {
        System.out.println("El administrador está generando un reporte de ventas...");
    }
    @Override
public void mostrarMenu() {
    System.out.println("Menú de Administrador: puede gestionar productos, clientes y reportes.");
}
}