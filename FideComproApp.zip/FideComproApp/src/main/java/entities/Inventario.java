/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entities;

/**
 *
 * @author Moises
 */
import entities.Producto;
import java.util.ArrayList;
import java.util.List;

public class Inventario {
    private List<Producto> productos;
    
    public Inventario() {
        this.productos = new ArrayList<>();
    }
    
    public void agregarProducto(Producto producto) {
        productos.add(producto);
    }
    
    public boolean eliminarProducto(String id) {
        return productos.removeIf(p -> p.getId().equals(id));
    }
    
    public Producto buscarProducto(String id) {
        return productos.stream()
                       .filter(p -> p.getId().equals(id))
                       .findFirst()
                       .orElse(null);
    }
    
    public List<Producto> getProductos() {
        return new ArrayList<>(productos);
    }
    
    public List<Producto> getProductosStockBajo() {
        List<Producto> stockBajo = new ArrayList<>();
        for (Producto p : productos) {
            if (p.getStock() < 10) {
                stockBajo.add(p);
            }
        }
        return stockBajo;
    }
    
    public void alertaStockBajo() {
        List<Producto> stockBajo = getProductosStockBajo();
        if (!stockBajo.isEmpty()) {
            System.out.println("\n=== ALERTAS DE STOCK BAJO ===");
            for (Producto p : stockBajo) {
                System.out.println(p.getNombre() + " - Stock: " + p.getStock());
            }
            System.out.println("==============================\n");
        }
    }
}