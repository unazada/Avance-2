/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entities;

/**
 *
 * @author Moises
 */
import entities.ItemFactura;
import entities.Producto;
import entities.Cliente;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

public class Factura {
    private String id;
    private Cliente cliente;
    private Date fecha;
    private List<ItemFactura> items;
    private double total;
    
    public Factura(Cliente cliente) {
        this.id = UUID.randomUUID().toString().substring(0, 8);
        this.cliente = cliente;
        this.fecha = new Date();
        this.items = new ArrayList<>();
        this.total = 0.0;
    }
    
    // Getters
    public String getId() { return id; }
    public Cliente getCliente() { return cliente; }
    public Date getFecha() { return fecha; }
    public List<ItemFactura> getItems() { return items; }
    public double getTotal() { return total; }
    
    public void agregarItem(Producto producto, int cantidad) {
        if (producto.getStock() >= cantidad) {
            ItemFactura item = new ItemFactura(producto, cantidad);
            items.add(item);
            total += item.getSubtotal();
            producto.actualizarStock(-cantidad); // Reducir stock
        } else {
            System.out.println("Stock insuficiente para " + producto.getNombre());
        }
    }
    
    public void generarPDF() {
        System.out.println("\n=== FACTURA FIDECOMPRO ===");
        System.out.println("Factura ID: " + id);
        System.out.println("Fecha: " + fecha);
        System.out.println("Cliente: " + cliente.getNombre());
        System.out.println("Email: " + cliente.getEmail());
        System.out.println("---------------------------");
        
        for (ItemFactura item : items) {
            System.out.println(item);
        }
        
        System.out.println("---------------------------");
        System.out.println("TOTAL: $" + total);
        System.out.println("=== FIN FACTURA ===\n");
        
        System.out.println("Factura generada como PDF: factura_" + id + ".pdf");
    }
    
    @Override
    public String toString() {
        return String.format("Factura{id='%s', cliente='%s', fecha=%s, total=%.2f}", 
                           id, cliente.getNombre(), fecha, total);
    }
}