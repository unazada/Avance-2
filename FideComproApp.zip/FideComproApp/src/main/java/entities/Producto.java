/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entities;

/**
 *
 * @author Moises
 */
public class Producto {
    private String id;
    private String nombre;
    private String categoria;
    private double precio;
    private int stock;
    
    public Producto(String id, String nombre, String categoria, double precio, int stock) {
        this.id = id;
        this.nombre = nombre;
        this.categoria = categoria;
        this.precio = precio;
        this.stock = stock;
    }
    
    // Getters y Setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    
    public String getCategoria() { return categoria; }
    public void setCategoria(String categoria) { this.categoria = categoria; }
    
    public double getPrecio() { return precio; }
    public void setPrecio(double precio) { this.precio = precio; }
    
    public int getStock() { return stock; }
    public void setStock(int stock) { this.stock = stock; }
    
    public void actualizarStock(int cantidad) {
        this.stock += cantidad;
        System.out.println("Stock actualizado: " + nombre + " - Nuevo stock: " + stock);
        
        if (this.stock < 10) {
            System.out.println("ALERTA Stock bajo para el producto: " + nombre);
        }
    }
    
    @Override
    public String toString() {
        return String.format("Producto{id='%s', nombre='%s', categoria='%s', precio=%.2f, stock=%d}", 
                           id, nombre, categoria, precio, stock);
    }
}