/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entities;

/**
 *
 * @author Moises
 */
public class Empleado extends Usuario {

    public Empleado(String id, String username, String password) {
        super(id, username, password, Rol.EMPLEADO);
    }

    public void registrarVenta() {
        System.out.println("El empleado está registrando una venta...");
    }
    @Override
public void mostrarMenu() {
    System.out.println("Menú de Empleado: puede registrar ventas y gestionar inventario.");
}

}