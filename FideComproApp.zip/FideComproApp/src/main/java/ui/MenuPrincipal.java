/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ui;

/**
 *
 * @author Moises
 */
import entities.*;
import services.*;
import java.util.Scanner;

public class MenuPrincipal {
    private Scanner scanner;
    private Autenticacion authService;
    private ServicioCliente clienteService;
    private Inventario inventario;
    private ServicioFacturacion facturacionService;
    
    public MenuPrincipal() {
        this.scanner = new Scanner(System.in);
        this.authService = new Autenticacion();
        this.clienteService = new ServicioCliente();
        this.inventario = new Inventario();
        this.facturacionService = new ServicioFacturacion(inventario, clienteService);
        inicializarDatos();
    }
    
    private void inicializarDatos() {
        inventario.agregarProducto(new Producto("P001", "Arroz", "Granos", 2.50, 50));
        inventario.agregarProducto(new Producto("P002", "Azucar", "Endulzantes", 1.80, 30));
        inventario.agregarProducto(new Producto("P003", "Aceite", "Aceites", 4.20, 20));
        inventario.agregarProducto(new Producto("P004", "Leche", "Lacteos", 3.10, 5)); 
        inventario.agregarProducto(new Producto("P005", "Harina", "Harinas", 1.50, 40));
    }
    
    public void iniciar() {
        System.out.println("=== SISTEMA FIDECOMPRO ===");
        
        while (true) {
            if (!authService.isAuthenticated()) {
                mostrarLogin();
            } else {
                mostrarMenuPrincipal();
            }
        }
    }
    
    private void mostrarLogin() {
        System.out.println("\n=== INICIO DE SESION ===");
        System.out.print("Usuario: ");
        String username = scanner.nextLine();
        System.out.print("Contrasena: ");
        String password = scanner.nextLine();
        
        authService.login(username, password);
    }
    
    private void mostrarMenuPrincipal() {
        System.out.println("\n=== MENU PRINCIPAL ===");
        System.out.println("Usuario: " + authService.getUsuarioActual().getUsername());
        System.out.println("1. Gestion de Clientes");
        System.out.println("2. Gestion de Productos");
        System.out.println("3. Facturacion");
        System.out.println("4. Inventario");
        System.out.println("5. Cerrar Sesion");
        System.out.println("0. Salir");
        System.out.print("Seleccione una opcion: ");
        
        int opcion = Integer.parseInt(scanner.nextLine());
        
        switch (opcion) {
            case 1:
                menuClientes();
                break;
            case 2:
                menuProductos();
                break;
            case 3:
                menuFacturacion();
                break;
            case 4:
                menuInventario();
                break;
            case 5:
                authService.logout();
                break;
            case 0:
                System.out.println("¡Gracias por usar Fidecompro!");
                System.exit(0);
                break;
            default:
                System.out.println("Opcion no valida");
        }
    }
    
    private void menuClientes() {
        while (true) {
            System.out.println("\n=== GESTION DE CLIENTES ===");
            System.out.println("1. Listar Clientes");
            System.out.println("2. Registrar Cliente");
            System.out.println("3. Buscar Cliente");
            System.out.println("4. Volver al Menu Principal");
            System.out.print("Seleccione una opcion: ");
            
            int opcion = Integer.parseInt(scanner.nextLine());
            
            switch (opcion) {
                case 1:
                    listarClientes();
                    break;
                case 2:
                    registrarCliente();
                    break;
                case 3:
                    buscarCliente();
                    break;
                case 4:
                    return;
                default:
                    System.out.println("Opcion no valida");
            }
        }
    }
    
    private void listarClientes() {
        System.out.println("\n=== LISTA DE CLIENTES ===");
        for (Cliente cliente : clienteService.listarClientes()) {
            System.out.println(cliente);
        }
    }
    
    private void registrarCliente() {
    System.out.println("\n=== REGISTRAR CLIENTE ===");
    System.out.print("Nombre: ");
    String nombre = scanner.nextLine();
    System.out.print("Direccion: ");
    String direccion = scanner.nextLine();
    System.out.print("Telefono: ");
    String telefono = scanner.nextLine();
    System.out.print("Email: ");
    String email = scanner.nextLine();
    
    try {
        clienteService.registrarCliente(nombre, direccion, telefono, email);
    } catch (exceptions.DatosInvalidosException e) {
        System.out.println("Error al registrar cliente: " + e.getMessage());
    }
}
    
    private void buscarCliente() {
        System.out.print("ID del cliente: ");
        String id = scanner.nextLine();
        Cliente cliente = clienteService.buscarCliente(id);
        if (cliente != null) {
            System.out.println("Cliente encontrado: " + cliente);
        } else {
            System.out.println("Cliente no encontrado");
        }
    }
    
    private void menuProductos() {
        while (true) {
            System.out.println("\n=== GESTION DE PRODUCTOS ===");
            System.out.println("1. Listar Productos");
            System.out.println("2. Agregar Producto");
            System.out.println("3. Buscar Producto");
            System.out.println("4. Volver al Menu Principal");
            System.out.print("Seleccione una opcion: ");
            
            int opcion = Integer.parseInt(scanner.nextLine());
            
            switch (opcion) {
                case 1:
                    listarProductos();
                    break;
                case 2:
                    agregarProducto();
                    break;
                case 3:
                    buscarProducto();
                    break;
                case 4:
                    return;
                default:
                    System.out.println("Opcion no valida");
            }
        }
    }
    
    private void listarProductos() {
        System.out.println("\n=== LISTA DE PRODUCTOS ===");
        for (Producto producto : inventario.getProductos()) {
            System.out.println(producto);
        }
    }
    
    private void agregarProducto() {
        System.out.println("\n=== AGREGAR PRODUCTO ===");
        System.out.print("Nombre: ");
        String nombre = scanner.nextLine();
        System.out.print("Categoria: ");
        String categoria = scanner.nextLine();
        System.out.print("Precio: ");
        double precio = Double.parseDouble(scanner.nextLine());
        System.out.print("Stock: ");
        int stock = Integer.parseInt(scanner.nextLine());
        
        String id = "P" + String.format("%03d", inventario.getProductos().size() + 1);
        Producto producto = new Producto(id, nombre, categoria, precio, stock);
        inventario.agregarProducto(producto);
        System.out.println("Producto agregado exitosamente");
    }
    
    private void buscarProducto() {
        System.out.print("ID del producto: ");
        String id = scanner.nextLine();
        Producto producto = inventario.buscarProducto(id);
        if (producto != null) {
            System.out.println("Producto encontrado: " + producto);
        } else {
            System.out.println("Producto no encontrado");
        }
    }
    
    private void menuFacturacion() {
        while (true) {
            System.out.println("\n=== FACTURACION ===");
            System.out.println("1. Crear Factura");
            System.out.println("2. Listar Facturas");
            System.out.println("3. Volver al Menu Principal");
            System.out.print("Seleccione una opcion: ");
            
            int opcion = Integer.parseInt(scanner.nextLine());
            
            switch (opcion) {
                case 1:
                    crearFactura();
                    break;
                case 2:
                    listarFacturas();
                    break;
                case 3:
                    return;
                default:
                    System.out.println("Opcion no valida");
            }
        }
    }
    
    private void crearFactura() {
        System.out.println("\n=== CREAR FACTURA ===");
        System.out.print("ID del cliente: ");
        String clienteId = scanner.nextLine();
        
        Factura factura = facturacionService.crearFactura(clienteId);
        if (factura == null) return;
        
        // Agregar productos a la factura
        while (true) {
            System.out.println("\nAgregar producto a la factura:");
            System.out.print("ID del producto (o 'fin' para terminar): ");
            String productoId = scanner.nextLine();
            
            if (productoId.equalsIgnoreCase("fin")) {
                break;
            }
            
            System.out.print("Cantidad: ");
            int cantidad = Integer.parseInt(scanner.nextLine());
            
            facturacionService.agregarProductoAFactura(factura, productoId, cantidad);
        }
        
        // Generar PDF
        System.out.print("¿Generar factura PDF? (s/n): ");
        String respuesta = scanner.nextLine();
        if (respuesta.equalsIgnoreCase("s")) {
            facturacionService.generarFacturaPDF(factura);
        }
    }
    
    private void listarFacturas() {
        System.out.println("\n=== LISTA DE FACTURAS ===");
        for (Factura factura : facturacionService.listarFacturas()) {
            System.out.println(factura);
        }
    }
    
    private void menuInventario() {
        while (true) {
            System.out.println("\n=== INVENTARIO ===");
            System.out.println("1. Ver Inventario Completo");
            System.out.println("2. Alertas de Stock Bajo");
            System.out.println("3. Volver al Menu Principal");
            System.out.print("Seleccione una opcion: ");
            
            int opcion = Integer.parseInt(scanner.nextLine());
            
            switch (opcion) {
                case 1:
                    listarInventario();
                    break;
                case 2:
                    alertasStockBajo();
                    break;
                case 3:
                    return;
                default:
                    System.out.println("Opcion no valida");
            }
        }
    }
    
    private void listarInventario() {
        System.out.println("\n=== INVENTARIO COMPLETO ===");
        for (Producto producto : inventario.getProductos()) {
            System.out.println(producto);
        }
    }
    
    private void alertasStockBajo() {
        inventario.alertaStockBajo();
    }
}