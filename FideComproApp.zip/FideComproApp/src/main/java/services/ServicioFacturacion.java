/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package services;

/**
 *
 * @author Moises
 */
import entities.*;
import java.util.ArrayList;
import java.util.List;

public class ServicioFacturacion {
    private List<Factura> facturas;
    private Inventario inventario;
    private ServicioCliente clienteService;
    
    public ServicioFacturacion(Inventario inventario, ServicioCliente clienteService) {
        this.facturas = new ArrayList<>();
        this.inventario = inventario;
        this.clienteService = clienteService;
    }
    
    public Factura crearFactura(String clienteId) {
        Cliente cliente = clienteService.buscarCliente(clienteId);
        if (cliente == null) {
            System.out.println("Cliente no encontrado");
            return null;
        }
        
        Factura factura = new Factura(cliente);
        facturas.add(factura);
        System.out.println("Factura creada para: " + cliente.getNombre());
        return factura;
    }
    
    public void agregarProductoAFactura(Factura factura, String productoId, int cantidad) {
        if (factura == null) return;
        
        Producto producto = inventario.buscarProducto(productoId);
        if (producto != null) {
            factura.agregarItem(producto, cantidad);
        } else {
            System.out.println("Producto no encontrado");
        }
    }
    
    public void generarFacturaPDF(Factura factura) {
        if (factura != null) {
            factura.generarPDF();
        }
    }
    
    public List<Factura> listarFacturas() {
        return new ArrayList<>(facturas);
    }
}