/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package services;

/**
 *
 * @author Moises
 */
import entities.Usuario;
import java.util.HashMap;
import java.util.Map;

public class Autenticacion{
    private Map<String, Usuario> usuarios;
    private Usuario usuarioActual;
    
    public Autenticacion() {
        this.usuarios = new HashMap<>();
        inicializarUsuarios();
    }
    
    private void inicializarUsuarios() {
        usuarios.put("admin", new Usuario("1", "admin", "admin", Usuario.Rol.ADMINISTRADOR));
        usuarios.put("empleado", new Usuario("2", "empleado", "empleado", Usuario.Rol.EMPLEADO));
    }
    
    public boolean login(String username, String password) {
        Usuario usuario = usuarios.get(username);
        if (usuario != null && usuario.login(username, password)) {
            usuarioActual = usuario;
            System.out.println("Login exitoso. Bienvenido " + usuario.getUsername());
            return true;
        }
        System.out.println("Credenciales incorrectas");
        return false;
    }
    
    public void logout() {
        if (usuarioActual != null) {
            usuarioActual.logout();
            usuarioActual = null;
        }
    }
    
    public Usuario getUsuarioActual() {
        return usuarioActual;
    }
    
    public boolean isAuthenticated() {
        return usuarioActual != null;
    }
}