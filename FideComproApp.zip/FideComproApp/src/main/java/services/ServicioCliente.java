/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package services;

/**
 *
 * @author Moises
 */
import entities.Cliente;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import exceptions.DatosInvalidosException;
import java.io.*;

public class ServicioCliente {
    private List<Cliente> clientes;
    
    public ServicioCliente() {
        this.clientes = new ArrayList<>();
        clientes.add(new Cliente("C001", "Moises Barrientos", "100m sur plaza de deportes", "8555-1234", "moises@email.com"));
        clientes.add(new Cliente("C002", "María Garcia", "Del Supermercado al final", "8555-5678", "maria@email.com"));
    }
    
    public void registrarCliente(String nombre, String direccion, String telefono, String email) throws DatosInvalidosException {
    if (!email.contains("@") || !email.contains(".")) {
        throw new DatosInvalidosException("Correo electrónico inválido: " + email);
    }

    String id = "C" + String.format("%03d", clientes.size() + 1);
    Cliente cliente = new Cliente(id, nombre, direccion, telefono, email);
    clientes.add(cliente);
    cliente.registrar();
}
    
    public List<Cliente> listarClientes() {
        return new ArrayList<>(clientes);
    }
    
    public Cliente buscarCliente(String id) {
        return clientes.stream()
                      .filter(c -> c.getId().equals(id))
                      .findFirst()
                      .orElse(null);
    }
    
    public boolean actualizarCliente(String id, String nombre, String direccion, String telefono, String email) {
        Cliente cliente = buscarCliente(id);
        if (cliente != null) {
            cliente.setNombre(nombre);
            cliente.setDireccion(direccion);
            cliente.setTelefono(telefono);
            cliente.setEmail(email);
            cliente.actualizar();
            return true;
        }
        return false;
    }
    public void guardarClientes() {
    try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("clientes.dat"))) {
        oos.writeObject(clientes);
        System.out.println("Clientes guardados correctamente.");
    } catch (IOException e) {
        System.out.println("Error al guardar clientes: " + e.getMessage());
    }
}
}
